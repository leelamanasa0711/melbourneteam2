var path = require("path");
var isAuthenticated = require("../config/middleware/isAuthenticated");
var isAuthorised = require("../config/middleware/isAuthorised");


module.exports = function (app) {
  app.get("/", function (req, res) {
    if (req.user) {
      res.redirect("/home");
    }
    res.sendFile(path.join(__dirname, "../public/login.html"));
  });
  app.get("/login", function (req, res) {
    if (req.user) {
      res.redirect("/home");
    }
    res.sendFile(path.join(__dirname, "../public/login.html"));
  });

  //HTML Routes for user
  app.get("/home", isAuthenticated, isAuthorised("readOwn", "docs"), function (req, res) {
    res.sendFile(path.join(__dirname, "../public/home.html"));
  });

  app.get("/employee", isAuthenticated, isAuthorised("readOwn", "profile"), function (req, res) {
    res.sendFile(path.join(__dirname, "../public/employee.html"));
  });

  app.get("/profile", isAuthenticated, isAuthorised("readOwn", "profile"), function (req, res) {
    res.sendFile(path.join(__dirname, "../public/profile.html"));
  });
  
  //admin
  app.get("/upload",isAuthenticated,function(req,res){
    res.sendFile(path.join(__dirname, "../public/upload.html"));
  })

  //super admin
  app.get("/superadmin", isAuthenticated, isAuthorised("createAny", "profile"), function (req, res) {
    res.sendFile(path.join(__dirname, "../public/superadmin.html"));
  });
  app.get("/usermapping", isAuthenticated, function (req, res) {
    res.sendFile(path.join(__dirname, "../public/usermapping.html"));
  });






};