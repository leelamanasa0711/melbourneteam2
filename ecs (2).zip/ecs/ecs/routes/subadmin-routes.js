var db = require("../models");
var express = require('express');
var router = express.Router();
var isAuthenticated = require("../config/middleware/isAuthenticated");
var isAuthorised = require("../config/middleware/isAuthorised");
var bcrypt = require("bcrypt");

//Sub Admin routes
router.get("/:id", isAuthenticated,function (req, res) {
    const sub_admin_id = req.params.id;
    db.SubAdmin.findAll({
        where: { sub_admin_id: sub_admin_id }
    })
      .then(result => {
        res.json(result);
      }).catch(err => {
        res.json(err);
      });
  });

  router.get("/employee/:id", isAuthenticated,function (req, res) {
    const empId = req.params.id;
    db.SubAdmin.findAll({
        where: { emp_id: empId }
    })
      .then(result => {
        res.json(result);
      }).catch(err => {
        res.json(err);
      });
  });

  router.post("/",function(req,res){
    db.SubAdmin.upsert({
        emp_id : req.body.empId,
        sub_admin_id : req.body.subAdminId
    }).then(function (result) {
        res.json(result);
      }).catch(function (err) {
        res.json(err);
      });
  });

module.exports = router;