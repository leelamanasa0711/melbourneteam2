var db = require("../models");
var express = require('express');
var router = express.Router();
var isAuthenticated = require("../config/middleware/isAuthenticated");
var isAuthorised = require("../config/middleware/isAuthorised");
var bcrypt = require("bcrypt");


//API routes of user
router.get("/", function (req, res) {
  db.Employee.findAll().then(function (data) {
    res.status(200).send({ users: data });
  }).catch(function (err) {
    res.status(500);
    res.json(err);
  });
});

router.post("/", isAuthenticated, isAuthorised("createAny", "profile"), function (req, res) {
  const password = bcrypt.hashSync(req.body.password, bcrypt.genSaltSync(10), null);
  db.Employee.upsert({
    fname: req.body.fName,
    lname: req.body.lName,
    email: req.body.email,
    password: password,
    RoleId: req.body.RoleId,
    DepartmentId: req.body.DepartmentId
  }).then(function () {
    res.redirect(200,"/");
  }).catch(function (err) {
    res.json(err);
  });
});

router.get("/id/:id", isAuthenticated,function (req, res) {
  const id = req.params.id;
  db.Employee.findOne({
    where: { id: id }
  })
    .then(result => {
      res.json(result);
    }).catch(err => {
      res.json(err);
    });
});

router.get("/email/:email", isAuthenticated, isAuthorised("deleteAny", "profile"),function (req, res) {
  const email = req.params.email;
  db.Employee.findOne({
    where: { email: email }
  })
    .then(result => {
      res.redirect("/");
    }).catch(err => {
      res.json(err);
    });
});

router.get("/role/:role", isAuthenticated,function (req, res) {
  const role = req.params.role;
  db.Employee.findAll({
    include: [{
      model: db.Role,
      where: {role_name: role}
     }]
  })
    .then(result => {
      res.json(result);
    }).catch(err => {
      res.json(err);
    });
});

router.delete("/:email", isAuthenticated, isAuthorised("deleteAny", "profile"),function (req, res) {
  const email = req.params.email;
  db.Employee.destroy({
    where: { email: email }
  })
    .then(result => {
      res.redirect("/");
    }).catch(err => {
      res.json(err);
    });
});


router.get("/currentuser", function (req, res) {
  if (!req.user) {
    res.json({});
  }
  else {
    res.json({
      fname: req.user.fname,
      lname: req.user.lname,
      email: req.user.email,
      role: req.user.RoleId,
      dept: req.user.DepartmentId,
      id: req.user.id
    });
  }
});

module.exports = router;
