var db = require("../models");
var express = require('express');
var router = express.Router();
var isAuthenticated = require("../config/middleware/isAuthenticated");
var isAuthorised = require("../config/middleware/isAuthorised");

//Super Admin routes
router.get("/", isAuthenticated,function (req, res) {
  db.Role.findAll()
    .then(result => {
      res.json(result);
    }).catch(err => {
      res.json(err);
    });
});

router.get("/:id", isAuthenticated,function (req, res) {
    const roleId = req.params.id;
    db.Role.findByPk(roleId)
      .then(result => {
        res.json(result);
      }).catch(err => {
        res.json(err);
      });
  });

module.exports = router;