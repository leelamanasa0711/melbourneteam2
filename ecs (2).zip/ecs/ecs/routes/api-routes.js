var db = require("../models");
var fs = require('fs');
var mime = require('mime');
var path = require('path');
var passport = require("../config/passport");
var isAuthenticated = require("../config/middleware/isAuthenticated");
var isAuthorised = require("../config/middleware/isAuthorised");

module.exports = function (app) {
  app.post("/api/login", function (req, res, next) {
    console.log("login function");
    passport.authenticate('local', function (err, user, info) {
      if (err) { return next(err); }
      if (!user) {
        res.json(401, { error: info.message });
      }
      req.logIn(user, function (err) {
        if (err) {
          res.json(401, { error: info.message });
        }
        res.redirect(200, '/');
      });
    })(req, res, next);
  });

  app.post("/api/signup", function (req, res) {

    db.Employee.create({
      fname: req.body.fName,
      lname: req.body.lName,
      email: req.body.email,
      password: req.body.password,
      RoleId: 4,
    }).then(function (data) {

      res.redirect(307, "/api/login");
    }).catch(function (err) {
      res.status(500)
      res.json(err);
    });
  });


  app.get('/download/:fileName', isAuthenticated, (req, res) => {
    var fileName = req.params.fileName;
    try {
      const file = `${__dirname}/../public/files/${fileName}`;
      res.download(file);
    } catch (err) {
      console.log(err)
    }
  })

  app.get("/logout", function (req, res) {
    req.logout();
    res.redirect("/");
  });


};