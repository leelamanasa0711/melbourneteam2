var db = require("../models");
var express = require('express');
var router = express.Router();
var isAuthenticated = require("../config/middleware/isAuthenticated");
var isAuthorised = require("../config/middleware/isAuthorised");

router.get("/admin/:adminId", isAuthenticated, function (req, res) {
    const adminId = req.params.adminId;
    db.Document.findAll({
        where: {
            admin_id: [adminId, 1]
        }
    })
        .then(result => {
            res.json(result);
        }).catch(err => {
            res.json(err);
        });
});

router.get("/department/:deptId/admin/:adminId", isAuthenticated, function (req, res) {
    const deptId = req.params.deptId;
    const adminId = req.params.adminId;
    db.Document.findAll({
        where: {
            dept_id: deptId,
            admin_id: [adminId, 1]
        }
    }).then(result => {
        res.json(result);
    }).catch(err => {
        res.json(err);
    });
});


module.exports = router;