var db = require("../models");
var express = require('express');
var router = express.Router();
var isAuthenticated = require("../config/middleware/isAuthenticated");
var isAuthorised = require("../config/middleware/isAuthorised");
const multer = require('multer');
const path = require('path');
var fs = require("fs");



//Sub Admin routes
router.get("/:id", isAuthenticated, function (req, res) {
  const adminId = req.params.id;
  db.Admin.findAll({
    where: { admin_id: adminId }
  })
    .then(result => {
      res.json(result);
    }).catch(err => {
      res.json(err);
    });
});

router.get("/employee/:id", isAuthenticated, function (req, res) {
  const subAdminId = req.params.id;
  db.Admin.findAll({
    where: { sub_admin_id: subAdminId }
  })
    .then(result => {
      res.json(result);
    }).catch(err => {
      res.json(err);
    });
});

router.post("/", function (req, res) {
  db.Admin.upsert({
    sub_admin_id: req.body.subAdminId,
    admin_id: req.body.adminId
  }).then(function (result) {
    res.json(result);
  }).catch(function (err) {
    res.json(err);
  });
});

const fileFilter = function (req, file, cb) {
  if (!file.originalname.match(/\.(jpg|JPG|jpeg|JPEG|png|PNG|gif|GIF|word|pdf)$/)) {
    req.fileValidationError = 'Only word pdf and image files are allowed!';
    return cb(new Error('Only word pdf and image files are allowed!'), false);
  }
  cb(null, true);
};
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, __dirname + '/../public/files/');
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});
let upload = multer({ storage: storage, fileFilter: fileFilter }).single('file_name');
router.post("/upload", upload, function (req, res) {
  db.Document.create({
    title: req.body.title,
    description: req.body.description,
    file_name: req.file.filename,
    dept_id: req.body.deptId,
    admin_id: req.body.adminId
  }).then(function (result) {
    res.json(result);
  }).catch(function (err) {
    res.json(err);
  });
});

module.exports = router;