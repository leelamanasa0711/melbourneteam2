module.exports = function (sequelize, DataTypes) {
    var Document = sequelize.define("Document", {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true
        },
        title: {
            type: DataTypes.STRING,
            allowNull: false
        },
        description: {
            type: DataTypes.STRING,
            allowNull: false
        },
        file_name:{
            type: DataTypes.STRING,
            allowNull: false
        }
    });
    Document.associate = (models) =>{
        Document.belongsTo(models.Department, {foreignKey: 'dept_id'})
        Document.belongsTo(models.Employee, {foreignKey: 'admin_id'});
    }

    return Document;
};