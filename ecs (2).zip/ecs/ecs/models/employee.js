var bcrypt = require("bcrypt");

module.exports = function (sequelize, DataTypes) {
    var Employee = sequelize.define("Employee", {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true
        },
        fname: {
            type: DataTypes.STRING,
            allowNull: false
        },
        lname: {
            type: DataTypes.STRING,
            allowNull: true
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
            validate: {
                isEmail: true
            }
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false
        }

    });

      Employee.associate = (models) =>{
        Employee.belongsTo(models.Department, {foreignKey: 'DepartmentId', targetKey:'id'})
        Employee.belongsTo(models.Role, {foreignKey: 'RoleId', targetKey:'id'});
      }

    Employee.prototype.validPassword = function (password) {
        return bcrypt.compareSync(password, this.password);
    };

    Employee.beforeCreate(user => {
        user.password = bcrypt.hashSync(
            user.password,
            bcrypt.genSaltSync(10),
            null
        );
    });

    Employee.beforeUpsert(user => {
        user.password = bcrypt.hashSync(
            user.password,
            bcrypt.genSaltSync(10),
            null
        );
    });
    return Employee;
};