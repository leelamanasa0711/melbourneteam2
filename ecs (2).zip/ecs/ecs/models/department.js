module.exports = function (sequelize, DataTypes) {
    var Department = sequelize.define("Department", {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true
        },
        dept_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
    });
    
    Department.associate = (models) =>{
        Department.hasMany(models.Employee, {foreignkey:'DepartmentId', targetKey:'id'})
    }
    return Department;
};