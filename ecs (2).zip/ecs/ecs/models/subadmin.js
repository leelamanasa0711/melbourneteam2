module.exports = function (sequelize, DataTypes) {
    var SubAdmin = sequelize.define("SubAdmin", {
        emp_id:{
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true
        }
    });

    SubAdmin.associate = (models) =>{
        SubAdmin.belongsTo(models.Employee, {as:'employee', foreignKey: 'emp_id', onDelete: 'cascade' })
        SubAdmin.belongsTo(models.Employee, {as:'subadmin', foreignKey: 'sub_admin_id',onDelete: 'cascade'});
    }
    
    
    return SubAdmin;
};