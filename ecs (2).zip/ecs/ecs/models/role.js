module.exports = function (sequelize, DataTypes) {
    var Role = sequelize.define("Role", {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true
        },
        role_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
    });
    Role.associate = (models) =>{
        Role.hasMany(models.Employee, {foreignkey:'RoleId', targetKey:'id'})
    }
    return Role;
};