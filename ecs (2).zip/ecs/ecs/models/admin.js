module.exports = function (sequelize, DataTypes) {
    var Admin = sequelize.define("Admin", {
        sub_admin_id:{
            type: DataTypes.INTEGER,
            allowNull: false,
            primaryKey: true
        }
    });
    Admin.associate = (models) =>{
        Admin.belongsTo(models.Employee, {as:'subadmin',foreignKey: 'sub_admin_id',onDelete: 'cascade'})
        Admin.belongsTo(models.Employee, {as:'admin',foreignKey: 'admin_id',onDelete: 'cascade'});
    }
    
    return Admin;
};