var express = require('express');
var flash = require('connect-flash');
var path = require('path');
var logger = require('morgan');
var bodyParser = require("body-parser");
var session = require("express-session");
var passport = require("./config/passport");
var db = require("./models");
var usersRouter = require("./routes/user-routes")
var roleRouter = require("./routes/role-routes");
var subAdminRouter = require("./routes/subadmin-routes");
var adminRouter = require("./routes/admin-routes");
var deptRouter = require("./routes/dept-routes");
var documentRouter = require('./routes/document-routes');

require("dotenv").config({
  path: path.join(__dirname, "./.env")
 });

 const PORT = process.env.PORT || 8080;
 const isProduction = process.env.NODE_ENV === 'production';

var usersRouter = require('./routes/user-routes');

var app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false })); 
app.use(bodyParser.json());
app.use(flash());
app.use(express.static(path.join(__dirname, 'public')));


// We need to use sessions to keep track of our user's login status
app.use(session({ secret: "keyboard cat", resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());


// Requiring our routes
require("./routes/html-routes.js")(app);
require("./routes/api-routes.js")(app);
app.use('/api/user', usersRouter); 
app.use('/api/role', roleRouter); 
app.use('/api/subadmin', subAdminRouter); 
app.use('/api/admin', adminRouter); 
app.use('/api/dept', deptRouter); 
app.use('/api/document', documentRouter); 


db.sequelize.sync().then(function() {
  app.listen(PORT, function() {
    console.log("==> 🌎  Listening on port %s. Visit http://localhost:%s/ in your browser.", PORT, PORT);
  });
});

app.get('/flash', function(req, res){
  req.flash('info', 'Flash is back!')
  res.redirect('/');
});

//Error handlers & middlewares
if(!isProduction) {
  app.use((err, req, res,next) => {
    res.status(err.status || 500);

    res.json({
      errors: {
        message: err.message,
        error: err,
      },
    });
  });
}

app.use((err, req, res,next) => {
  res.status(err.status || 500);
  res.json({
    errors: {
      message: err.message,
      error: {},
    },
  });
});


module.exports = app;
