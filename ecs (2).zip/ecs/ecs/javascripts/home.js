$(document).ready(function () {
    var empId = "";
    var deptId = "";
    var subAdminId = "";
    var adminId = "";
    $.get("/api/user/currentUser").then(function (data) {
        $(".member-name").text(data.fname);
        updateRoleInfo(data.role);
        id = data.id;
        deptId = data.dept;
        if (data.role === 1){
            findSubAdmin(id);
            $("#employeePanel").css('display','none');
        }
        if (data.role === 2) {
            findAdmin(id, false)
            findEmployeesUnderSubAdmin(id);
        }
        if (data.role === 3) {
            loadDocumentsForRolesOtherThanEmployees(id);
            findEmployeesUnderAdmin(id);
        }
        if (data.role === 4) {
            loadDocumentsForRolesOtherThanEmployees(id);
            $("#employeePanel").css('display','none');
        }
    })

    function findSubAdmin(empId) {
        $.ajax({
            url: `/api/subadmin/employee/${empId}`,
            type: 'GET',
            success: function (result) {
                subAdminId = result[0].sub_admin_id;
                findAdmin(subAdminId, true);
            }
        });
    }

    function findAdmin(subAdminId, isEmployee) {
        $.ajax({
            url: `/api/admin/employee/${subAdminId}`,
            type: 'GET',
            success: function (result) {
                adminId = result[0].admin_id;
                if (isEmployee) {
                    loadDocuments(adminId);
                } else {
                    loadDocumentsForRolesOtherThanEmployees(adminId);
                }

            }
        });
    }
    function loadDocuments(adminId) {
        $.ajax({
            url: `/api/document/department/${deptId}/admin/${adminId}`,
            type: 'GET',
            success: function (result) {
                $.each(result, (key, value) => {
                    var row = `<tr>
                    <td>${value.title}</td>
                    <td>${value.description}</td>
                    <td colspan="3"><a href="/download/${value.file_name}">${value.file_name}</a></td>
                    </tr>`
                    $("#documentDetails").append(row);
                })

            }
        });
    }

    function loadDocumentsForRolesOtherThanEmployees(adminId) {
        $.ajax({
            url: `/api/document/admin/${adminId}`,
            type: 'GET',
            success: function (result) {
                $.each(result, (key, value) => {
                    var row = `<tr>
                    <td>${value.title}</td>
                    <td>${value.description}</td>
                    <td colspan="3"><a href="/download/${value.file_name}">${value.file_name}</a></td>
                    </tr>`
                    $("#documentDetails").append(row);
                })

            }
        });
    }

    function findEmployeesUnderAdmin(adminId){
        $.ajax({
            url: `/api/admin/${adminId}`,
            type: 'GET',
            success: function (result) {
                $.each(result, (key, value) => {
                    findEmployeesUnderSubAdmin(value.sub_admin_id);
                })
            }
        });
    }
    function findEmployeesUnderSubAdmin(empId) {
        $("#employeesList").empty();
            $.ajax({
                url: `/api/subadmin/${empId}`,
                type: 'GET',
                success: function (result) {
                    $.each(result, (key, value) => {
                        findEmp(value);
                    })
                }
            });
    }

    function findEmp(subAdminObject) {
        $.ajax({
            url: `/api/user/id/${subAdminObject.emp_id}`,
            type: 'GET',
            success: function (result) {
                $("#employeesList").append(`<li>${result.fname} - ${result.email} </li>`);
                console.log(result)
            }
        });
    }

});

function updateRoleInfo(roleId) {
    $.ajax({
        url: `/api/role/${roleId}`,
        type: 'GET',
        success: function (result) {
            $(".member-role").text(result.role_name);
            if (result.role_name === 'superadmin') {
                $('.nav li.superadmin').css('display', 'block');
                $('.nav li.usermapping').css('display', 'block');
                $('.nav li.upload').css('display', 'block');
            }
            if (result.role_name === 'admin') {
                $('.nav li.upload').css('display', 'block');
            }
        }
    });
}