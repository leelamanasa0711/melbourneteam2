$(document).ready(function () {
    $.get("/api/user/currentUser").then(function (data) {
       
        $(".member-fname").text(data.fname);
        $(".member-lname").text(data.lname);
        $(".member-email").text(data.email);
        updateRoleInfo(data.role);
        
    })
});

function updateRoleInfo(roleId){
    $.ajax({
        url: `/api/role/${roleId}`,
        type: 'GET',
        success: function (result) {
            $(".member-role").text(result.role_name);
            if (result.role_name === 'superadmin') {
                $('.nav li.superadmin').css('display', 'block');
                $('.nav li.usermapping').css('display', 'block');
                $('.nav li.upload').css('display', 'block');
            }
            if (result.role_name === 'admin') {
                $('.nav li.upload').css('display', 'block');
            }
            
        }
    });
}