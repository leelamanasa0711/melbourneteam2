$(document).ready(function () {
    var currentUserId = '';
    $.ajax({
        url: `/api/dept/`,
        type: 'GET',
        success: function (result) {
            $.each(result, function (key, value) {
                $("<option></option>",
                    { value: value.id, text: value.dept_name })
                    .appendTo('#dept-input');
            });
        }
    });

    $.get("/api/user/currentUser").then(function (data) {
        currentUserId = data.id;
        updateRoleInfo(data.role);
    })

    function updateRoleInfo(roleId){
        $.ajax({
            url: `/api/role/${roleId}`,
            type: 'GET',
            success: function (result) {
                $(".member-role").text(result.role_name);
                if (result.role_name === 'superadmin') {
                    $('.nav li.superadmin').css('display', 'block');
                    $('.nav li.usermapping').css('display', 'block');
                    $('.nav li.upload').css('display', 'block');
                }
                if (result.role_name === 'admin') {
                    $('.nav li.upload').css('display', 'block');
                }
            }
        });
    }

    $("form.uploadForm").on("submit", function (event) {
        event.preventDefault();
        var formData = new FormData();
        var title = $("#title").val();
        var description = $("#description").val();
        var fileName = $("#file_name").prop('files')[0];
        var deptId = $("#dept-input").val();
        var adminId = currentUserId;
        formData.append("title",title);
        formData.append("description",description);
        formData.append("file_name",fileName);
        formData.append("deptId",deptId);
        formData.append("adminId",adminId);
        $.ajax({
            url: '/api/admin/upload',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            successs: function(result) {
                $('#uploadMsg').css('display','none');
                $('#uploadMsg').text("File uploaded successfully");
              console.log(result);
            },
            error: function(error) {
              $('#uploadErrorMsg').css('display','none');
              $('#uploadErrorMsg').text("Error in File Upload"+error);
            }
          })
    });
});