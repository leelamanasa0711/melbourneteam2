$(document).ready(function () {
  var dropdown = $('#role-input').empty()
  $.getJSON("roles.json", function (json) {
    const roles = JSON.parse(JSON.stringify(json));
    $.each(roles, function (key, value) {
      dropdown.append('<option value=' + key + '>' + value + '</option>');
    });
  });
  var signUpForm = $("form.signup");
  var fNameInput = $("input#fName-input");
  var lNameInput = $("input#lName-input");
  var emailInput = $("input#email-input");
  var passwordInput = $("input#password-input");
  //var roleInput = $("select#role-input");

  // When the signup button is clicked, we validate the email and password are not blank
  signUpForm.on("submit", function (event) {
    var empty = false;
    event.preventDefault();
    if (!fNameInput.val()) {
      $("#fnamediv").addClass("has-error");
      empty = true;
    } else {
      $("#fnamediv").removeClass("has-error");
    }

    if (!lNameInput.val()) {
      $("#lnamediv").addClass("has-error");
      empty = true;
    } else {
      $("#lnamediv").removeClass("has-error");
    }

    if (!emailInput.val()) {
      $("#emaildiv").addClass("has-error");
      empty = true;
    } else {
      $("#emaildiv").removeClass("has-error");
    }

    if (!passwordInput.val()) {
      $("#pwddiv").addClass("has-error");
      empty = true;
    } else {
      $("#pwddiv").removeClass("has-error");
    }

    // if (!roleInput.val()) {
    //   $("#rolediv").addClass("has-error");
    //   empty = true;
    // } else {
    //   $("#rolediv").removeClass("has-error");
    // }

    if (empty) {
      return;
    }

    var userData = {
      fName: fNameInput.val().trim(),
      lName: lNameInput.val().trim(),
      email: emailInput.val().trim(),
      password: passwordInput.val().trim()
    //  role: roleInput.val().trim()
    };

    
    // If we have an email and password, run the signUpUser function
    signUpUser(userData.fName, userData.lName, userData.email, userData.password);
    fNameInput.val("");
    lNameInput.val("");
    emailInput.val("");
    passwordInput.val("");
   // roleInput.val("");
  });

  // Does a post to the signup route. If succesful, we are redirected to the members page
  // Otherwise we log any errors
  function signUpUser(fName, lName, email, password) {
    $.post("/api/signup", {
      fName: fName,
      lName: lName,
      email: email,
      password: password
     // role: role
    }).then(function (data) {
      window.location.replace("/")
    }).catch(handleLoginErr);
  }

  function handleLoginErr(err) {
    const error = JSON.parse(JSON.stringify(err));
    if((error.responseJSON.name).includes('UniqueConstraint')){
      $("#alert .msg").text("Email already exists");
      $("#alert").fadeIn(500);
    }
    
    
  }
});
