$(document).ready(function () {
    $.get("/api/user/currentuser").then(function (data) {
        $(".member-name").text(data.fname);
        $(".member-email").text(data.email);
    });

    $.ajax({
        url: `/api/user/role/employee`,
        type: 'GET',
        success: function (result) {
            var index = 1;
            $.each(result, function (key, value) {
                $("<option></option>",
                    { value: value.id, text: value.email })
                    .appendTo('#employees');
                if (index == 1) {
                    $("#mappedEmployee").text($("#employees").text())
                    $.ajax({
                        url: `/api/subadmin/employee/${value.id}`,
                        type: 'GET',
                        success: function (result) {
                            setSubAdminName(result);
                        }
                    });
                    index = 2;
                }
            });
        }
    });

    $('#employees').on('change', function () {
        $("#mappedEmployee").text($("#employees option:selected").text())
        $.ajax({
            url: `/api/subadmin/employee/${this.value}`,
            type: 'GET',
            success: function (result) {
                setSubAdminName(result)
            }
        });
    });
    function setSubAdminName(subadmin) {
        if (subadmin[0] && subadmin[0].sub_admin_id) {
            $.ajax({
                url: `/api/user/id/${subadmin[0].sub_admin_id}`,
                type: 'GET',
                success: function (result) {
                    $("#mappedSubAdmin").text(result.email)
                    $("#subadmins").val(result.id);
                }
            });
        } else {
            $("#mappedSubAdmin").text("NILL ")
            $("#subadmins").val("-1");
        }
    }

    $.ajax({
        url: `/api/user/role/subadmin`,
        type: 'GET',
        success: function (result) {
            var index = 1;
            $.each(result, function (key, value) {
                $("<option></option>",
                    { value: value.id, text: value.email })
                    .appendTo('#subadmins');
                $("<option></option>",
                    { value: value.id, text: value.email })
                    .appendTo('#subadminList');

                if (index == 1) {
                    $("#mappedSubAdmin2").text($("#subadminList").text())
                    $.ajax({
                        url: `/api/admin/${value.id}`,
                        type: 'GET',
                        success: function (result) {
                            setAdminName(result);
                        }
                    });
                    index = 2;
                }
            });
        }
    });

    $('#subadminList').on('change', function () {
        $("#mappedSubAdmin2").text($("#subadminList option:selected").text())
        $.ajax({
            url: `/api/admin/employee/${this.value}`,
            type: 'GET',
            success: function (result) {
                setAdminName(result)
            }
        });
    });
    function setAdminName(admin) {
        if (admin[0] && admin[0].admin_id) {
            $.ajax({
                url: `/api/user/id/${admin[0].admin_id}`,
                type: 'GET',
                success: function (result) {
                    $("#mappedAdmin").text(result.email)
                    $("#admins").val(result.id);
                }
            });
        } else {
            $("#mappedAdmin").text("NILL ")
            $("#admins").val("-1");
        }
    }

    $.ajax({
        url: `/api/user/role/admin`,
        type: 'GET',
        success: function (result) {
            var index = 1;
            $.each(result, function (key, value) {
                $("<option></option>",
                    { value: value.id, text: value.email })
                    .appendTo('#admins');
                if (index == 1) {
                    $("#mappedSubAdmin2").text($("#subadminList").text())
                    $.ajax({
                        url: `/api/admin/${value.id}`,
                        type: 'GET',
                        success: function (result) {
                            setAdminName(result);
                        }
                    });
                    index = 2;
                }
            });
        }
    });

    $("form.subadminmapping").on("submit", function (event) {
        var empId = $("#employees").val();
        var subAdminId = $("#subadmins").val();
        $.post("/api/subadmin/", {
            empId: empId,
            subAdminId: subAdminId
        }).then(function (data) {
            window.location.replace("/usermapping")
        }).catch(handleLoginErr);
    });

    $("form.adminmapping").on("submit", function (event) {
        var subAdminId = $("#subadminList").val();
        var adminId = $("#admins").val();
        $.post("/api/admin/", {
            subAdminId: subAdminId,
            adminId: adminId
        }).then(function (data) {
            window.location.replace("/usermapping")
        }).catch(handleLoginErr);
    });
});

function handleLoginErr(err) {
    $("#alert .msg").text(err.responseJSON.error);
    $("#alert").fadeIn(500);
}