$(document).ready(function () {
  //API Calls
  // Get current user details
  $.get("/api/user/currentUser").then(function (data) {
    $(".member-name").text(data.fname);
    $(".member-email").text(data.email);
    if (data.role === 'superadmin') {
      $('.nav li.superadmin').css('display', 'block');
    }
    if (data.role === 'admin') {
      $('.nav li.admin').css('display', 'block');
    }
  });
});