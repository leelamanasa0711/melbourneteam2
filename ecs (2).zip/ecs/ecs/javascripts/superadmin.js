$(document).ready(function () {

  var actions = '<a class="add" title="Add" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a>' +
    '<a class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>' +
    '<a class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE872;</i></a>';

  //API Calls
  // Get current user details
  $.get("/api/user/currentuser").then(function (data) {
    $(".member-name").text(data.fname);
    $(".member-email").text(data.email);
  });

  //Fetch All users in the system
  $.get("/api/user/").then(function (data) {
    var index = 0;
    $.each(data, function (key, users) {
      $.each(users, function (key, user) {
        if(!(user.RoleId === 4)){
          var row = '<tr>' +
          '<td><input type="text" class="form-control" name="fName" id="fName' + index + '" value=' + user.fname + ' disabled="disabled"></td>' +
          '<td><input type="text" class="form-control" name="lName" id="lName' + index + '" value=' + user.lname + ' disabled="disabled"></td>' +
          '<td><input type="text" class="form-control" name="email" id="email' + index + '" value=' + user.email + ' disabled="disabled"></td>' +
          '<td><select class="form-control form-control-sm"  id="dept-input' + index + '" disabled="disabled">' +
          '</select> </td>' +
          '<td><select class="form-control form-control-sm"  id="role-input' + index + '" disabled="disabled">' +
          '</select> </td>' +
          '<td><input type="password" class="form-control" name="password" id="password' + index + '" value=' + user.password + ' disabled="disabled"></td>' +
          '<td>' + actions + '</td>' +
          '</tr>';
        $("table").append(row);
        $("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
        addDept(index, user.DepartmentId);
        addRoles(index, user.RoleId);
        index++;
        }
      });
    });
    $(".member-name").text(data.fname);
    $(".member-email").text(data.email);
  });

  function addDept(index, deptId) {
    $.ajax({
      url: `/api/dept/`,
      type: 'GET',
      success: function (result) {
        $.each(result, function (key, value) {
          $("<option></option>",
            { value: value.id, text: value.dept_name })
            .appendTo('#dept-input' + index);
          $("#dept-input" + index).val(deptId);
        });
      }
    });
  }

  function addRoles(index, roleId) {
    $.ajax({
      url: `/api/role/`,
      type: 'GET',
      success: function (result) {
        $.each(result, function (key, value) {
          $("<option></option>",
            { value: value.id, text: value.role_name })
            .appendTo('#role-input' + index);
          $("#role-input" + index).val(roleId);
        });
      }
    });
  }
  //UI Chnages
  $('[data-toggle="tooltip"]').tooltip();
  $(".add-new").click(function () {
    $(this).attr("disabled", "disabled");
    var index = $("table tbody tr:last-child").index();
    var idIndex = index + 1;
    var row = '<tr>' +
      '<td><input type="text" class="form-control" name="fName" id="fName' + idIndex + '" value=""></td>' +
      '<td><input type="text" class="form-control" name="lName" id="lName' + idIndex + '"></td>' +
      '<td><input type="text" class="form-control" name="email" id="email' + idIndex + '"></td>' +
      '<td><select class="form-control form-control-sm"  id="dept-input' + idIndex + '" >' +
      '</select> </td>' +
      '<td><select class="form-control form-control-sm"  id="role-input' + idIndex + '" >' +
      '</select> </td>' +
      '<td><input type="password" class="form-control" name="password" id="password' + idIndex + '"></td>' +
      '<td><a class="add" title="Add" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a></td>' +
      '</tr>';
    $("table").append(row);
    $("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
    $('[data-toggle="tooltip"]').tooltip();
    addDept(idIndex, 1);
    addRoles(idIndex,1);
  });

  $(document).on("click", ".add", function () {
    var rowNo = $(this).parents("tr").index();
    var empty = false;
    var input = $(this).parents("tr").find('input[type="text"]');
    var password = $(this).parents("tr").find('input[type="password"]');
    input.each(function () {
      if (!$(this).val()) {
        $(this).addClass("error");
        empty = true;
      } else {
        $(this).removeClass("error");
      }
    });
    password.each(function () {
      if (!$(this).val()) {
        $(this).addClass("error");
        empty = true;
      } else {
        $(this).removeClass("error");
      }
    });
    $(this).parents("tr").find(".error").first().focus();
    if (!empty) {
      var userData = {
        fName: $("#fName" + rowNo).val(),
        lName: $("#lName" + rowNo).val(),
        email: $("#email" + rowNo).val(),
        password: $("#password" + rowNo).val(),
        role: $("#role-input" + rowNo).val(),
        dept: $("#dept-input" + rowNo).val(),
      };
      input.each(function () {
        $(this).parent("td").html($(this).val());
      });
      password.each(function () {
        $(this).parent("td").html($(this).val());
      });
      $(this).parents("tr").find(".add, .edit").toggle();
      $(".add-new").removeAttr("disabled");

      if (!userData.fName || !userData.email || !userData.password) {
        return;
      }
      // If we have an email and password, run the signUpUser function
      addOrUpdateUser(userData.fName, userData.lName, userData.email, userData.password, userData.role,userData.dept);
      $("#fName" + rowNo).val("");
      $("#lName" + rowNo).val("");
      $("#email" + rowNo).val("");
      $("#password" + rowNo).val("");
    }
  });
  $(document).on("click", ".edit", function () {
    $(this).parents("tr").find("td input").each(function () {
      // $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
      //  /$(this).val($(this).text());
      $(this).removeAttr("disabled");
    });
    $(this).parents("tr").find("td select").each(function () {
      $(this).removeAttr("disabled");
    });
    $(this).parents("tr").find(".add, .edit").toggle();
    $(".add-new").attr("disabled", "disabled");
  });
  $(document).on("click", ".delete", function (e) {
    e.preventDefault();
    var row_index = $(this).parents("tr").index();
    const email = $('#email' + row_index).val();
    deleteUser(email);
    $(this).parents("tr").remove();
    $(".add-new").removeAttr("disabled");
  });
});

function addOrUpdateUser(fName, lName, email, password, role,dept) {
  $.post("/api/user/", {
    fName: fName,
    lName: lName,
    email: email,
    password: password,
    RoleId: role,
    DepartmentId:dept
  }).then(function (data) {
    window.location.replace("/superadmin")
  }).catch(handleLoginErr);
}

function deleteUser(email) {
  $.ajax({
    url: `/api/user/${email}`,
    type: 'DELETE',
    success: function (result) {
      console.log(result)
    }
  });
}

function handleLoginErr(err) {
  $("#alert .msg").text(err.responseJSON.error);
  $("#alert").fadeIn(500);
}





