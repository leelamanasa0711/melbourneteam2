$(document).ready(function () {

  // Getting references to our form and inputs
  var loginForm = $("form.login");
  var emailInput = $("input#email-input");
  var passwordInput = $("input#password-input");

  // When the form is submitted, we validate there's an email and password entered
  loginForm.on("submit", function (event) {
    event.preventDefault();
    var empty = false;
    if (!emailInput.val()) {
      $("#emailDiv").addClass("has-error");
      empty = true;
    } else {
      $("#emailDiv").removeClass("has-error");
    }
    if (!passwordInput.val()) {
      $("#passwordDiv").addClass("has-error");
      empty = true;
    } else {
      $("#passwordDiv").removeClass("has-error");
    }

    if (empty) {
      return;
    }
    var userData = {
      email: emailInput.val().trim(),
      password: passwordInput.val().trim()
    };

    loginUser(userData.email, userData.password);
    emailInput.val("");
    passwordInput.val("");
  });

  function loginUser(email, password) {
    $.post("/api/login", {
      email: email,
      password: password
    }).then(function (data) {
      window.location.replace("/");
    }).catch(function (err) {
      const error = JSON.parse(JSON.stringify(err));
      $("#alert .msg").text(error.responseJSON.error);
      $("#alert").fadeIn(500);
    });
  }
});
