const AccessControl = require("accesscontrol");
const ac = new AccessControl();

exports.roles = (function () {
    ac.grant("employee")
        .readOwn("docs")
        .readOwn("profile")

    ac.grant("subadmin")
        .extend("employee")

    ac.grant("admin")
        .extend("subadmin")
        .createAny("docs")

    ac.grant("superadmin")
        .extend("admin")
        .createAny("profile")
        .deleteAny("profile")

    return ac;
})();