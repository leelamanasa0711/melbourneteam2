const { roles } = require('../../security/rbac')
var db = require("../../models");

module.exports = function (action, resource) {
    return async (req, res, next) => {
        try {
            const role = await db.Role.findByPk(req.user.RoleId)
            const permission = roles.can(role.role_name)[action](resource);
            if (!permission.granted) {
                return res.status(401).json({
                    error: "You don't have enough permission to perform this action"
                });
            }
            next()
        } catch (error) {
            next(error)
        }
    }
}